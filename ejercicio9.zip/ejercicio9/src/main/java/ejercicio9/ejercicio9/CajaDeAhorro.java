package ejercicio9.ejercicio9;

public class CajaDeAhorro  extends Cuenta{
	public boolean extraer(double monto) {
		return super.extraer(monto*1.02);
		
	}
}
