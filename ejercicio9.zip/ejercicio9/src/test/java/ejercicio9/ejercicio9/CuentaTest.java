package ejercicio9.ejercicio9;

import static org.junit.jupiter.api.Assertions.assertEquals;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import ejercicio9.ejercicio9.CuentaCorriente;
import ejercicio9.ejercicio9.CajaDeAhorro;

@SuppressWarnings("unused")
public class CuentaTest {
	private CuentaCorriente cuenta1;
	private CajaDeAhorro cuenta2;
	
	@BeforeEach
	void setUp() throws Exception {
		cuenta1 = new CuentaCorriente();
		cuenta2 = new CajaDeAhorro();
		cuenta1.setDescubierto(100);
		cuenta1.depositar(100);
		cuenta2.depositar(300);
	}
	
	@Test
	public void testExtraccion() {
		assertEquals(true, cuenta1.extraer(199));
		assertEquals(true, cuenta2.extraer(299));
	}
	@Test
	public void testTransferencia() {
		assertEquals(true, cuenta1.transferirACuentra(199, cuenta2));
		assertEquals(true, cuenta2.transferirACuentra(499, cuenta1));
	}
}
