package ejercicio2.ejercicio6;
import java.time.LocalDate;
import java.util.Date;

public class Mamifero {
	private String identificador;
	private String especie;
	private LocalDate fechaNacimiento;
	private Mamifero padre;
	private Mamifero madre;
	
	public Mamifero(String identificador) {
		this.setIdentificador(identificador);
		this.fechaNacimiento = LocalDate.now();
		this.padre = null;
		this.madre = null;
	}
	public Mamifero() {
		
	}
	
	public String getIdentificador() {
		return identificador;
	}
	public void setIdentificador(String identificador) {
		this.identificador = identificador;
	}
	public String getEspecie() {
		return especie;
	}
	public void setEspecie(String especie) {
		this.especie = especie;
	}
	public LocalDate getFechaNacimiento() {
		return fechaNacimiento;
	}
	public void setFechaNacimiento(LocalDate fechaNacimiento) {
		this.fechaNacimiento = fechaNacimiento;
	}
	public Mamifero getPadre() {
		return padre;
	}
	public void setPadre(Mamifero padre) {
		this.padre = padre;
	}
	public Mamifero getMadre() {
		return this.madre;
	}
	public void setMadre(Mamifero madre) {
		this.madre = madre;
	}
	
	public Mamifero getAbuelaMaterna() {
		if (this.hasMadre()) {
			return this.getMadre().getMadre();
		} 
		return null;
	}
	
	public Mamifero getAbueloMaterno() {
		if (this.hasMadre()) {
			return this.getMadre().getPadre();
		}
		return null;
	}
	
	public Mamifero getAbuelaPaterna() {
		if (this.hasPadre()) {
			return this.padre.getMadre();
		}
		return null;
	}
	
	public Mamifero getAbueloPaterno() {
		if (this.hasPadre()) {
			return this.padre.getPadre();
		}
		return null;
	}
	
	private boolean hasPadre() {
		return this.padre != null;
	}
	private boolean hasMadre() {
		return this.madre != null;
	}
	private boolean ancestro(Mamifero unMamifero) {
		return this.equals(unMamifero)||(this.hasMadre()&& this.getMadre().ancestro(unMamifero))|| this.hasPadre() && this.getPadre().ancestro(unMamifero);
	}
	
	public boolean tieneComoAncestroA(Mamifero unMamifero) {
		return !this.equals(unMamifero) && ((this.hasMadre() && this.getMadre().ancestro(unMamifero)) || (this.hasPadre() && this.getPadre().ancestro(unMamifero)));
	}
}
